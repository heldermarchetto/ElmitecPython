from setuptools import setup
setup(
 name='readUview',
 version='1.0',
 description='Import of images from uView (ELMITEC) propietary file data format!',
 author='Helder Marchetto',
 author_email='helder.marchetto@gmail.com',
 url='www.marchetto.de',
 py_modules=['readUview'],
)
